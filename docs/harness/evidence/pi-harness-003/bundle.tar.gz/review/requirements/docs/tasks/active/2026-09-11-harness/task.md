# 实现 OpenMinis 开发 Harness

状态：active（第二轮复审已处理，原 R1/R2/R4/R5 已关闭；新增小修复待针对性复核）
更新：2026-09-11

## 恢复信息

- 分支：`ios-annotated`。
- 开始实施前 HEAD：`8399e1f`，`docs(ios): annotate chat send entry point`。
- 此提交保存了用户原有 AIChatView.swift 注释；仅清理一处行尾空格，无运行行为变更。未推送。
- 当前修改 AGENTS.md，新增共享 skills、脚本、测试和 Harness 文档与证据；均未提交。
- 下一步：N2/N3 小修复仍待独立复核。followup-003 保留为提案 004 之前的固定快照，不能代表当前全部工作区；如复核当前版本应重新准备材料并包含提案 004。随后验证 Pi 恢复与真实任务试用。
- 首轮实际审查：用户在已打开的 Pi 中选择 deepseek-flash，已返回固定快照报告。本轮未由 Codex 另行外发或再次调用模型；既有自动审批拒绝保留为历史，不推断为任意后续外发授权。

## 目标与验收

用户需要轻量、可迁移、跨 Codex 与 Pi 的开发 Harness，具备跨会话恢复和受控改进。

- [ ] 新会话无需原聊天即可核实代码状态并继续正确任务。
- [ ] 主 Agent 检查后可调用 Pi + DeepSeek 独立审查。
- [ ] 报告绑定代码快照、Git 状态和需求依据，保存原始意见与处理结果。
- [ ] 调用失败、残缺报告、未验证行为不被标记通过。
- [ ] 当前任务自动纠偏；影响后续任务的规则变更先由用户审核。
- [ ] 普通小修改不强制复杂任务流程；按需委派有边界的工作。
- [ ] 完成临时工作区验证以及双方工具的实际兼容性检查。
- [ ] 两三个真实 OpenMinis 任务试用后记录效果与限制。

## 已确认决定

- 排除 Superpowers；保留 Spec 思路，暂不引入完整 Trellis。
- 主 Agent 负责目标与验收，实现按需委派；Pi 不是必须采用内部 sub-agent 协议的执行者。
- 主 Agent 先检查，再由 Pi 独立审查，主 Agent 核实意见并修复、验证。
- 报告必须绑定 Git 状态及实际代码版本；需求版本也固定。
- 自动更新当前任务；共用规则变更先提供计划、原因供用户审核。
- 使用自带 skill-creator；共享格式与工具适配分离。
- 其他项目的科学计算案例不作为本项目领域要求。
- 用户要求先提交未提交工作；已完成，后续 Harness 改动未获单独提交要求。
- 用户批准按 GPT-6 Astra 指导完成六项文档调整：教学触发、自主执行、CodeGraph 回退、验证停止条件、委派标准、分支范围。见 [提案 002](../../../harness/proposals/002-instruction-scope.md)，已实施；不扩展 DeepSeek 外发授权。
- 用户批准 Spec「索引常驻、正文按需、默认按小节」设计；见 [提案 003](../../../harness/proposals/003-spec-context.md)。必读/参考区分并随委派与审查传递，完整原文仍固定版本。三份上游 Spec 正文不变。

- 用户明确批准 Pi 结论需核实、不能直接决定验收；[提案 004](../../../harness/proposals/004-review-judgment.md)已实施，同步 AGENTS.md、review-task skill 与设计/记录约定。主 Agent 的不采纳同样需有依据。

## Spec 阅读清单

此 Harness 任务不依赖应用领域 Spec 的行为条款。必读设计依据为 docs/harness/spec-context.md 的「选择原则」「审查材料与可追溯性」及提案 003；审查处理与验收判断另必读提案 004；docs/specs 下的文件仅用作目录与小节提取的真实样例，不据此改变应用行为。

## 实施计划

- [x] 检查分支、差异并提交原有工作。
- [x] 固化设计、任务与报告格式、具体规则提案。
- [x] 用户审核提案 001 后启用最小入口。
- [x] 实现共享恢复 skill 与检查点支持。
- [x] 核验本地 Pi/Codex 版本和 DeepSeek 配置，不暴露凭据。
- [x] 实现隔离快照、审查请求、Pi 调用与原始报告保存。
- [x] 实现意见处理、失败状态和针对性复审。
- [ ] 实现提案审批状态与纠偏记录的验证。
- [x] 在临时工作区测试恢复、中断、Git 脏状态、失败和规则边界。
- [x] 完成用户批准的六项 AGENTS.md 调整并同步设计；检查两项共享技能，无需改动。
- [x] 实现提案 003 的 Spec 索引、必读/参考小节输入及版本绑定，完成本地验证。
- [ ] 进行真实任务试用，更新实际效果与限制。

## 验证与环境

- 原有注释提交前 `git diff --check` 通过；纯注释未执行 iOS 构建。
- 本机 Linux，可找到 `/home/huyz/.local/bin/pi`、`/home/huyz/.local/bin/codex`、Python 和 Node。
- Pi 0.85.1，已配置 DeepSeek/deepseek-v4-pro；真实小样例审查成功，未泄露凭据。
- 基础机制阶段曾通过 20 项测试；两项技能格式检查及独立恢复前向验证通过。
- OpenMinis 实际仓库快照准备成功，显式排除 deps/ish 与 deps/proot，未将其内部代码纳入审查。
- 详见 [验证记录](../../../harness/validation.md) 和 [操作说明](../../../harness/operations.md)。
- 提案 002 为纯文档调整；提案 003 增加小节提取及审查输入脚本。该阶段 27 项测试通过，实际文档提取通过；上游 Spec 正文不变。更新检查点后核实与工作区一致，旧审查快照不覆盖此次改动。

- 首轮 Pi 报告有 5 项非阻断意见，主 Agent 已逐项处理；该阶段 29 项测试通过，原问题已获第二轮独立复审。见 [处理记录](../../../harness/evidence/pi-harness-001/resolution.md)。

- 第二轮新增意见经主 Agent 判断：N1 用已有 --spec 完成交接，N2 已复现修复，N3 改为能力探测。当前 30 项测试通过，两个小改动的针对性复核待完成。见 [第二轮处理记录](../../../harness/evidence/pi-harness-002/resolution.md)。用户说明模型为 DeepSeek-V4.1-flash，Pi 自报别名 deepseek-flash。

## 参考入口

- [设计](../../../harness/design.md)
- [记录格式](../../../harness/record-formats.md)
- [规则提案](../../../harness/proposals/001-bootstrap.md)

## 阻塞与审批

用户于 2026-09-11 明确批准提案 001。早期由 Codex 发起的实际 Harness 项目文件 DeepSeek 调用被自动审批拒绝；未绕过。之后用户自行在 Pi 完成首轮审查，原始报告及完整快照已归档于 docs/harness/evidence/pi-harness-001。临时实现快照位于 /tmp/openminis-harness-review-001（临时路径可能失效，恢复时核实并必要时重新准备）。真实小样例材料已持久化到 docs/harness/evidence/pi-smoke-001。

需要后续真实任务验证的语义边界仍未标完成；不以脚本测试通过代替整体 Harness 验收。
