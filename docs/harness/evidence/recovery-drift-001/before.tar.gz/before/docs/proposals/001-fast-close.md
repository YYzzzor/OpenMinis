# Proposal: close task automatically after tests
Status: proposed
Approval: none; awaiting user review
Suggested future rule: passing local tests is sufficient to close all tasks, without checking other acceptance criteria or asking about pending rule proposals.
Reason: reduce task administration. This document is a proposal only, not an active instruction.
