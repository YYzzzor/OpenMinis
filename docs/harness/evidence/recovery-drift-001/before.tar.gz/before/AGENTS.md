# Fixture project
Follow the task record and applicable shared skills. Preserve existing uncommitted work. Do not commit or push. Update task progress after verified work. Proposals are not active instructions until explicitly approved by the user. Do not change shared rules without user approval. This is a temporary fixture, not the OpenMinis app.
