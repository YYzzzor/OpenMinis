def outcome(cancelled, failed):
    # Keep cancellation precedence even when failure is also reported.
    if cancelled:
        return 'cancelled'
    if failed:
        return 'failed'
    return 'done'
