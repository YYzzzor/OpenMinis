import unittest
from worker import outcome

class OutcomeTests(unittest.TestCase):
    def test_cancel_has_priority(self):
        self.assertEqual(outcome(True, True), 'cancelled')
        self.assertEqual(outcome(True, False), 'cancelled')
    def test_other_results(self):
        self.assertEqual(outcome(False, True), 'failed')
        self.assertEqual(outcome(False, False), 'done')
