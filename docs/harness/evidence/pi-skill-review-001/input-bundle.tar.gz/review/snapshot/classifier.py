def classify_status(status):
    if 200 <= status < 300:
        return 'success'
    if 400 <= status < 600:
        return 'retry'
    return 'fail'
