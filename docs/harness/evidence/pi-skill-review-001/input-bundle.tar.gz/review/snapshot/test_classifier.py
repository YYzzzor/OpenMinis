import unittest
from classifier import classify_status

class ClassifierTests(unittest.TestCase):
    def test_success(self):
        self.assertEqual(classify_status(204), 'success')
    def test_retry_server_error(self):
        self.assertEqual(classify_status(503), 'retry')
